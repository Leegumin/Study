package com.jpafirst.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpafirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpafirstApplication.class, args);
	}

}
