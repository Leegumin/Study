package com.jpafirst.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpafirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
